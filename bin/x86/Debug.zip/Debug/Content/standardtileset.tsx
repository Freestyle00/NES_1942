<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="TiledIcons" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="StandardTilesetIcons.png" width="512" height="512"/>
 <tile id="0" type="SolidCollision"/>
 <tile id="1" type="BreakableCollision"/>
 <tile id="2" type="CloudCollision"/>
 <tile id="3" type="OneWayCollision"/>
 <tile id="32" type="Water"/>
 <tile id="33" type="IceCollision"/>
 <tile id="64" type="Door"/>
 <tile id="96" type="Ladder"/>
</tileset>
